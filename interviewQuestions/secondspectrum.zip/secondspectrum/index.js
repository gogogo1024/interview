const csvFilePath = 'values.csv'

const csv = require('csvtojson')
const { processCsvData } = require('./largestAbsIncr')
csv()
    .fromFile(csvFilePath)
    .then((jsonObj) => {
        processCsvData(jsonObj)
    })
